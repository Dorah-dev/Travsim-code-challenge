# Movie-Search-Engine-using-OMDb-API-in-Node-js
A simple movie search engine web app using OMDb API in Node js, inspired by Colt Steele

